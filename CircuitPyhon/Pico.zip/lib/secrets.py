# secrets.py
secrets = {
  "ssid": "",
  "password": ""
}