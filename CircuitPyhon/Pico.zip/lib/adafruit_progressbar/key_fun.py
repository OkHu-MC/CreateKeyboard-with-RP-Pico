import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode
import time

from adafruit_hid.mouse import Mouse
kbd = Keyboard(usb_hid.devices)
cc = ConsumerControl(usb_hid.devices)
# USB HID�}�E�X�f�o�C�X�̏�����
mouse_device = Mouse(usb_hid.devices)
kbd.release_all()
def function_1():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.ALT)
 kbd.press(Keycode.F1)
 time.sleep(0.1)
 kbd.release_all()
 pass
def function_2():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.ALT)
 kbd.press(Keycode.F2)
 time.sleep(0.1)
 kbd.release_all()
 pass
def function_3():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.ALT)
 kbd.press(Keycode.F3)
 time.sleep(0.1)
 kbd.release_all()
 pass
def function_4():
 pass
def function_5():
 pass
def function_6():
 pass
def function_7():
 pass
def function_8():
 pass
def function_9():
 pass
def function_10():
 pass
def function_11():
 pass
def function_12():
 pass
def function_13():
 pass
def function_14():
 pass
def function_15():
 pass
def function_16():
 pass
def function_17():
 pass
def function_18():
 pass
def function_19():
 pass
def function_20():
 pass
 
def KFprint(id):
    return id

function_list = {}


function_list.setdefault("1",function_1)
function_list.setdefault("2",function_2)
function_list.setdefault("3",function_3)
function_list.setdefault("4",function_4)
function_list.setdefault("5",function_5)
function_list.setdefault("6",function_6)
function_list.setdefault("7",function_7)
function_list.setdefault("8",function_8)
function_list.setdefault("9",function_9)
function_list.setdefault("10",function_10)
function_list.setdefault("11",function_11)
function_list.setdefault("12",function_12)
function_list.setdefault("13",function_13)
function_list.setdefault("14",function_14)
function_list.setdefault("15",function_15)
function_list.setdefault("16",function_16)
function_list.setdefault("17",function_17)
function_list.setdefault("18",function_18)
function_list.setdefault("19",function_19)
function_list.setdefault("20",function_20)

print("function::",function_list.keys())

'''
# Test ���W���[�����̊֐������擾 
function_names = [name for name in dir(Test) if callable(getattr(Test, name))] # "function" �Ƃ������O�̊֐����𒊏o
function_names_with_function = [name for name in function_names if
"function" in name] print("Test.py ���W���[������ function �֐��ꗗ:") for name in
function_names_with_function: print(name)
'''
