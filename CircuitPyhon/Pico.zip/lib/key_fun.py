import usb_hid
from adafruit_hid.keyboard import Keyboard
from adafruit_hid.keycode import Keycode
from adafruit_hid.consumer_control import ConsumerControl
from adafruit_hid.consumer_control_code import ConsumerControlCode
import time

from adafruit_hid.mouse import Mouse
kbd = Keyboard(usb_hid.devices)
cc = ConsumerControl(usb_hid.devices)
# USB HID�}�E�X�f�o�C�X�̏�����
mouse_device = Mouse(usb_hid.devices)
kbd.release_all()
def function_1():
 kbd.press(Keycode.BACKSPACE)
 pass
def function_1_R():
 kbd.release(Keycode.BACKSPACE)
 pass
def function_2():
 kbd.press(Keycode.KEYPAD_ASTERISK)
 pass
def function_2_R():
 kbd.release(Keycode.KEYPAD_ASTERISK)
 pass
def function_3():
 kbd.press(Keycode.KEYPAD_FORWARD_SLASH)
 pass
def function_3_R():
 kbd.release(Keycode.KEYPAD_FORWARD_SLASH)
 pass
def function_4():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.K)
 pass
def function_4_R():
 kbd.release(Keycode.CONTROL)
 kbd.release(Keycode.K)
 pass
def function_5():
 kbd.press(Keycode.KEYPAD_MINUS)
 pass
def function_5_R():
 kbd.release(Keycode.KEYPAD_MINUS)
 pass
def function_6():
 kbd.press(Keycode.KEYPAD_NINE)
 pass
def function_6_R():
 kbd.release(Keycode.KEYPAD_NINE)
 pass
def function_7():
 kbd.press(Keycode.KEYPAD_EIGHT)
 pass
def function_7_R():
 kbd.release(Keycode.KEYPAD_EIGHT)
 pass
def function_8():
 kbd.press(Keycode.KEYPAD_SEVEN)
 pass
def function_8_R():
 kbd.release(Keycode.KEYPAD_SEVEN)
 pass
def function_9():
 kbd.press(Keycode.KEYPAD_PLUS)
 pass
def function_9_R():
 kbd.release(Keycode.KEYPAD_PLUS)
 pass
def function_10():
 kbd.press(Keycode.KEYPAD_SIX)
 pass
def function_10_R():
 kbd.release(Keycode.KEYPAD_SIX)
 pass
def function_11():
 kbd.press(Keycode.KEYPAD_FIVE)
 pass
def function_11_R():
 kbd.release(Keycode.KEYPAD_FIVE)
 pass
def function_12():
 kbd.press(Keycode.KEYPAD_FOUR)
 pass
def function_12_R():
 kbd.release(Keycode.KEYPAD_FOUR)
 pass
def function_13():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.ALT)
 kbd.press(Keycode.F13)
 time.sleep(0.1)
 kbd.release_all()
 pass
def function_13_R():
 kbd.release(Keycode.ALT)
 kbd.release(Keycode.F13)
 kbd.release(Keycode.CONTROL)
 pass
def function_14():
 kbd.press(Keycode.KEYPAD_THREE)
 pass
def function_14_R():
 kbd.release(Keycode.KEYPAD_THREE)
 pass
def function_15():
 kbd.press(Keycode.KEYPAD_TWO)
 pass
def function_15_R():
 kbd.release(Keycode.KEYPAD_TWO)
 pass
def function_16():
 kbd.press(Keycode.KEYPAD_ONE)
 pass
def function_16_R():
 kbd.release(Keycode.KEYPAD_ONE)
 pass
def function_17():
 kbd.press(Keycode.CONTROL)
 kbd.press(Keycode.ALT)
 kbd.press(Keycode.F17)
 time.sleep(0.1)
 kbd.release_all()
 pass
def function_17_R():
 kbd.release(Keycode.ALT)
 kbd.release(Keycode.CONTROL)
 kbd.release(Keycode.F17)
 pass
def function_18():
 cc.send(ConsumerControlCode.VOLUME_INCREMENT)
 pass
def function_18_R():
 pass
def function_19():
 cc.send(ConsumerControlCode.VOLUME_DECREMENT)
 pass
def function_19_R():
 pass
def function_20():
 kbd.press(Keycode.KEYPAD_ZERO)
 pass
def function_20_R():
 kbd.release(Keycode.KEYPAD_ZERO)
 pass
 
def KFprint(id):
    return id

function_list = {}
ResetList ={}

function_list.setdefault("0",function_1)
function_list.setdefault("1",function_2)
function_list.setdefault("2",function_3)
function_list.setdefault("3",function_4)
function_list.setdefault("4",function_5)
function_list.setdefault("5",function_6)
function_list.setdefault("6",function_7)
function_list.setdefault("7",function_8)
function_list.setdefault("8",function_9)
function_list.setdefault("9",function_10)
function_list.setdefault("10",function_11)
function_list.setdefault("11",function_12)
function_list.setdefault("12",function_13)
function_list.setdefault("13",function_14)
function_list.setdefault("14",function_15)
function_list.setdefault("15",function_16)
function_list.setdefault("16",function_17)
function_list.setdefault("17",function_18)
function_list.setdefault("18",function_19)
function_list.setdefault("19",function_20)

ResetList.setdefault("0",function_1_R)
ResetList.setdefault("1",function_2_R)
ResetList.setdefault("2",function_3_R)
ResetList.setdefault("3",function_4_R)
ResetList.setdefault("4",function_5_R)
ResetList.setdefault("5",function_6_R)
ResetList.setdefault("6",function_7_R)
ResetList.setdefault("7",function_8_R)
ResetList.setdefault("8",function_9_R)
ResetList.setdefault("9",function_10_R)
ResetList.setdefault("10",function_11_R)
ResetList.setdefault("11",function_12_R)
ResetList.setdefault("12",function_13_R)
ResetList.setdefault("13",function_14_R)
ResetList.setdefault("14",function_15_R)
ResetList.setdefault("15",function_16_R)
ResetList.setdefault("16",function_17_R)
ResetList.setdefault("17",function_18_R)
ResetList.setdefault("18",function_19_R)
ResetList.setdefault("19",function_20_R)


print("function::",function_list.keys())

'''
# Test ���W���[�����̊֐������擾 
function_names = [name for name in dir(Test) if callable(getattr(Test, name))] # "function" �Ƃ������O�̊֐����𒊏o
function_names_with_function = [name for name in function_names if
"function" in name] print("Test.py ���W���[������ function �֐��ꗗ:") for name in
function_names_with_function: print(name)
'''
